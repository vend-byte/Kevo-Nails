module.exports=[90961,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_hours_route_actions_1as_lgv.js.map