module.exports=[746,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_announcements_%5Bid%5D_route_actions_17zw6uf.js.map