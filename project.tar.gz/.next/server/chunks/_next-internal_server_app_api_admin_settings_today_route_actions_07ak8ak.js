module.exports=[23920,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_today_route_actions_07ak8ak.js.map