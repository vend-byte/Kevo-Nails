module.exports=[6344,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_applications_create_route_actions_1to0n_o.js.map