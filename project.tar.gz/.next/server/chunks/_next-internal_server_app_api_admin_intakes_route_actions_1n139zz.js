module.exports=[78490,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_intakes_route_actions_1n139zz.js.map