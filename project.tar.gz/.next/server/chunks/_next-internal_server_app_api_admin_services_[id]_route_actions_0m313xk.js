module.exports=[79016,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_services_%5Bid%5D_route_actions_0m313xk.js.map