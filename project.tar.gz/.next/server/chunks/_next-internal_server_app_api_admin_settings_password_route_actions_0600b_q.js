module.exports=[92571,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_password_route_actions_0600b_q.js.map