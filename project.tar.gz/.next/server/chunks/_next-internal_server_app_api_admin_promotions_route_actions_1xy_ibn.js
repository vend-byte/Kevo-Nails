module.exports=[81863,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_promotions_route_actions_1xy_ibn.js.map