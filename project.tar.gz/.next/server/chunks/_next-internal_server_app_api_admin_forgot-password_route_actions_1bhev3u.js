module.exports=[15061,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_forgot-password_route_actions_1bhev3u.js.map